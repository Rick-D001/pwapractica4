<?php
session_start();
include("conexion.php");

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $_POST['usuario'];
    $clave = md5($_POST['clave']); // ← usamos MD5 porque así está en la BD

    $sql = "SELECT * FROM usuarios WHERE usuario = ? AND clave = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $usuario, $clave);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows == 1) {
        $usuario_data = $resultado->fetch_assoc();
        $_SESSION['usuario_id'] = $usuario_data['id'];
        $_SESSION['rol'] = $usuario_data['rol'];
        $_SESSION['usuario'] = $usuario_data['usuario'];

        if ($usuario_data['rol'] == 'docente') {
            header("Location: panel_docente.php");
        } elseif ($usuario_data['rol'] == 'estudiante') {
            header("Location: panel_estudiante.php");
        }
        exit;
    } else {
        $error = "❌ Usuario o contraseña incorrectos.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login - Sistema de Notas</title>
</head>
<body>
    <h2>Iniciar Sesión</h2>
    <form method="POST" action="">
        <label>Usuario:</label><br>
        <input type="text" name="usuario" required><br><br>

        <label>Contraseña:</label><br>
        <input type="password" name="clave" required><br><br>

        <input type="submit" value="Ingresar">
    </form>

    <?php if ($error != ""): ?>
        <p style="color:red;"><?php echo $error; ?></p>
    <?php endif; ?>
</body>
</html>
