<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] != 'docente') {
    header("Location: login.php");
    exit;
}

include 'conexion.php';

// Consulta de estudiantes activos
$sql = "SELECT * FROM estudiantes WHERE eliminado_en IS NULL";
$result = $conn->query($sql);
?>

<h2>Panel del Docente</h2>

<p><a href="agregar_estudiante.php">➕ Agregar nuevo estudiante</a></p>
<p><a href="ingresar_calificacion.php">📝 Ingresar calificación</a></p>
<p><a href="logout.php">🚪 Cerrar sesión</a></p>

<h3>Lista de Estudiantes</h3>
<table border="1" cellpadding="5">
    <tr>
        <th>Apellidos</th>
        <th>Nombres</th>
        <th>Email</th>
        <th>Creado en</th>
        <th>Acciones</th>
    </tr>
    <?php while ($estudiante = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($estudiante['apellidos']) ?></td>
            <td><?= htmlspecialchars($estudiante['nombres']) ?></td>
            <td><?= htmlspecialchars($estudiante['email']) ?></td>
            <td><?= $estudiante['creado_en'] ?></td>
            <td>
                <a href="editar_estudiante.php?id=<?= $estudiante['id'] ?>">✏️ Editar</a> |
                <a href="eliminar_estudiante.php?id=<?= $estudiante['id'] ?>" onclick="return confirm('¿Está seguro de eliminar este estudiante?')">🗑️ Eliminar</a> |
                <a href="ver_calificaciones.php?id=<?= $estudiante['id'] ?>">📄 Ver notas</a>
            </td>
        </tr>
    <?php endwhile; ?>
</table>
