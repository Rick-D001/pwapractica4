<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}
if ($_SESSION['rol'] == 'docente') {
    include 'panel_docente.php';
} else {
    include 'panel_estudiante.php';
}
?>
