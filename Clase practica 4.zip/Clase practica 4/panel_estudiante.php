<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include("conexion.php");

// Verifica que el usuario esté autenticado como estudiante
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] != 'estudiante') {
    header("Location: login.php");
    exit;
}

// Obtener el ID del usuario actual
$usuario_id = $_SESSION['usuario_id'];

// Obtener el ID del estudiante correspondiente al usuario
$sqlEstudiante = "SELECT id FROM estudiantes WHERE usuario_id = ?";
$stmtEstudiante = $conn->prepare($sqlEstudiante);
$stmtEstudiante->bind_param("i", $usuario_id);
$stmtEstudiante->execute();
$resultadoEstudiante = $stmtEstudiante->get_result();

if ($resultadoEstudiante->num_rows == 1) {
    $estudiante = $resultadoEstudiante->fetch_assoc();
    $estudiante_id = $estudiante['id'];

    // Obtener calificaciones del estudiante
    $sqlNotas = "SELECT materia, nota_teoria, nota_practica FROM calificaciones WHERE estudiante_id = ?";
    $stmtNotas = $conn->prepare($sqlNotas);
    $stmtNotas->bind_param("i", $estudiante_id);
    $stmtNotas->execute();
    $resultadoNotas = $stmtNotas->get_result();
} else {
    $estudiante_id = null;
    $resultadoNotas = false;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Panel del Estudiante</title>
</head>
<body>
    <h2>Bienvenido, <?php echo $_SESSION['usuario']; ?> (Estudiante)</h2>
    <a href="logout.php">🔓 Cerrar sesión</a>
    <h3>Mis Calificaciones</h3>

    <?php if ($resultadoNotas && $resultadoNotas->num_rows > 0): ?>
        <table border="1">
            <tr>
                <th>Materia</th>
                <th>Nota Teoría</th>
                <th>Nota Práctica</th>
            </tr>
            <?php while ($nota = $resultadoNotas->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($nota['materia']); ?></td>
                    <td><?php echo htmlspecialchars($nota['nota_teoria']); ?></td>
                    <td><?php echo htmlspecialchars($nota['nota_practica']); ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No tienes calificaciones registradas aún.</p>
    <?php endif; ?>
</body>
</html>
