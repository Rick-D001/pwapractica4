<?php
session_start();
if ($_SESSION['rol'] != 'docente') {
    header("Location: login.php");
    exit;
}

include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $estudiante_id = $_POST['estudiante_id'];
    $materia = $_POST['materia'];
    $nota_teoria = $_POST['nota_teoria'];
    $nota_practica = $_POST['nota_practica'];

    $sql = "INSERT INTO calificaciones (estudiante_id, materia, nota_teoria, nota_practica) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isdd", $estudiante_id, $materia, $nota_teoria, $nota_practica);

    if ($stmt->execute()) {
        echo "Calificación guardada.";
    } else {
        echo "Error: " . $conn->error;
    }
}

$result = $conn->query("SELECT id, apellidos, nombres FROM estudiantes WHERE eliminado_en IS NULL");
?>

<h2>Ingresar Calificación</h2>
<form method="post">
    Estudiante: 
    <select name="estudiante_id" required>
        <?php while ($row = $result->fetch_assoc()): ?>
            <option value="<?= $row['id'] ?>"><?= $row['apellidos'] ?> <?= $row['nombres'] ?></option>
        <?php endwhile; ?>
    </select><br>
    Materia: <input type="text" name="materia" required><br>
    Nota Teoría: <input type="number" step="0.01" name="nota_teoria" required><br>
    Nota Práctica: <input type="number" step="0.01" name="nota_practica" required><br>
    <input type="submit" value="Guardar">
</form>
<a href="panel.php">Volver al panel</a>
