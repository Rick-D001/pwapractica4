<?php
session_start();
if ($_SESSION['rol'] != 'docente') {
    header("Location: login.php");
    exit;
}

include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $apellidos = $_POST['apellidos'];
    $nombres = $_POST['nombres'];
    $email = $_POST['email'];
    $docente_id = $_SESSION['usuario_id'];

    $sql = "INSERT INTO estudiantes (apellidos, nombres, email, creado_por) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $apellidos, $nombres, $email, $docente_id);

    if ($stmt->execute()) {
        echo "Estudiante agregado correctamente.";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<h2>Agregar Estudiante</h2>
<form method="post">
    Apellidos: <input type="text" name="apellidos" required><br>
    Nombres: <input type="text" name="nombres" required><br>
    Email: <input type="email" name="email" required><br>
    <input type="submit" value="Guardar">
</form>
<a href="panel.php">Volver al panel</a>
