<?php
session_start();
if ($_SESSION['rol'] != 'docente') {
    header("Location: login.php");
    exit;
}

include 'conexion.php';

$id = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $apellidos = $_POST['apellidos'];
    $nombres = $_POST['nombres'];
    $email = $_POST['email'];

    $sql = "UPDATE estudiantes SET apellidos = ?, nombres = ?, email = ?, actualizado_en = NOW() WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $apellidos, $nombres, $email, $id);

    if ($stmt->execute()) {
        echo "Estudiante actualizado.";
    } else {
        echo "Error: " . $conn->error;
    }
}

$sql = "SELECT * FROM estudiantes WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();
$estudiante = $res->fetch_assoc();
?>

<h2>Editar Estudiante</h2>
<form method="post">
    Apellidos: <input type="text" name="apellidos" value="<?= $estudiante['apellidos'] ?>" required><br>
    Nombres: <input type="text" name="nombres" value="<?= $estudiante['nombres'] ?>" required><br>
    Email: <input type="email" name="email" value="<?= $estudiante['email'] ?>" required><br>
    <input type="submit" value="Actualizar">
</form>
<a href="panel.php">Volver al panel</a>
