<?php
session_start();
if ($_SESSION['rol'] != 'docente') {
    header("Location: login.php");
    exit;
}

include 'conexion.php';

$id = $_GET['id'];

$sql = "UPDATE estudiantes SET eliminado_en = NOW() WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "Estudiante marcado como eliminado.";
} else {
    echo "Error: " . $conn->error;
}
?>
<a href="panel.php">Volver al panel</a>
