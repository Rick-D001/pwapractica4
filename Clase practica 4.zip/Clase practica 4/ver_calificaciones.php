<?php
session_start();
if ($_SESSION['rol'] != 'docente') {
    header("Location: login.php");
    exit;
}
include 'conexion.php';

$estudiante_id = $_GET['id'];
$sql = "SELECT * FROM calificaciones WHERE estudiante_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $estudiante_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<h2>Notas del Estudiante</h2>
<table border="1" cellpadding="5">
    <tr>
        <th>Materia</th>
        <th>Teoría</th>
        <th>Práctica</th>
        <th>Fecha Ingreso</th>
    </tr>
    <?php while ($nota = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($nota['materia']) ?></td>
            <td><?= $nota['nota_teoria'] ?></td>
            <td><?= $nota['nota_practica'] ?></td>
            <td><?= $nota['creado_en'] ?></td>
        </tr>
    <?php endwhile; ?>
</table>
<a href="panel.php">⬅️ Volver al panel</a>
