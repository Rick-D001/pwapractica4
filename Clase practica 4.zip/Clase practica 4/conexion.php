<?php
$host = "localhost";
$usuario = "root";
$clave = ""; // por defecto en XAMPP no tiene contraseña
$bd = "sistema_notas";

$conn = new mysqli($host, $usuario, $clave, $bd);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>
